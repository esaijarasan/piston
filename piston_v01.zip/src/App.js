// import React from 'react';
// import logo from './logo.svg';
// import './App.css';
// import Footer from './components/Footer';
// import UserEntry from './components/UserEntry';
// import ChoosePrb from './components/ChoosePrb.js';
// import Hire from './components/Hire';
// import Dio from './components/Dio';
// import Pulser from './components/pulser';
// import HondaCivic from './components/hondaCivic';
// import HondaVezel from './components/HondaVezel';
// import Home from './components/Home';

// function App() {
//   return (
//    <div>

//   <UserEntry/>
//  <Footer/> 
//   {/* <Hire/>  */}
//  {/* <Dio/> */}
// {/* <Pulser/> */}
//  {/* <HondaCivic/>  */}
// {/* <HondaVezel/> */}
// {/* <ChoosePrb/>  */}

// {/* <div>





// </div> */}

// </div>
//   );
// }

// export default App;





import React, { Component } from "react";
import { BrowserRouter as Router, Switch, Route } from "react-router-dom";
import "./App.css";
// import MenuIcon from '@material-ui/icons/Menu';
import { Paper, Typography, AppBar, Toolbar, Button, IconButton } from "@material-ui/core";
import LibraryBooksOutlinedIcon from '@material-ui/icons/LibraryBooksOutlined';
import Home from "./components/Home";
// import ProminentAppBar from "/home/ukistu08/project_piston/src/components/Footer.js";
// import Login from "./components/login";
// import Register from "./components/register";
// import Home from "./components/home";
// import Profile from "./components/profile";
// import BoardUser from "./components/boardUser";
// import BoardAdmin from "./components/boardAdmin";
import { AccountCircle } from "@material-ui/icons";
import Hire from "./components/Hire";
import UserEntry from "./components/UserEntry";
import ChoosePrb from "./components/ChoosePrb";
import Dio from "./components/Dio";
import Pulser from "./components/pulser";
import HondaCivic from "./components/hondaCivic";
import HondaVezel from "./components/HondaVezel";
import Register from "./components/Register";
import FooterXXX from "./components/Footer";
import sociallink from "./components/sociallink";
import examPle from "./components/ddd";
import CustomizedInputs from "./components/colorDesign";
// import pRegister from "./components/register";
import FirstPage from "./components/First";
import Rent from "./components/rent";
import Profileo from "./components/Profileo";
import Sociallink from "./components/sociallink";
import Newservice from "./components/addnewService";
import Addnewservice from "./components/Addnewservice";
import GeoLocation from "./components/Geolocation";
import Sos from "./components/SOS";
import ContactUs from "./components/ContactUs";
import Timer from "./components/Endpage";
import History from "./components/history";
import Feedback from "./components/Feedback";

// import Footer from "./components/footer";

const style = {
  paper: {
    flexGrow: 1,
    backgroundColor: '#1a237e',
    color: '#c5cae9'
  },
  menuButton: {
    spacing: 2,
  },
  link: {
    underline: 'none'
  },
  appBar: {
    backgroundColor: "#1a237e"
  }
}
class App extends Component {
  constructor(props) {
    super(props);
    this.logOut = this.logOut.bind(this);
    this.state = {
      showAdminBoard: false,
      currentUser: undefined,
    };
  }

  componentDidMount() {
    let user;
    if (localStorage.getItem('username')) {
      user = {
        username: localStorage.getItem('username'),
        id: localStorage.getItem('id'),
        email: localStorage.getItem('email'),
        roles: localStorage.getItem('roles'),
      };
    }

    if (user) {
      this.setState({
        currentUser: user,
        showAdminBoard: user.roles.includes("ROLE_ADMIN")
      });
    }
  }

  logOut () {
    localStorage.clear()
  }

  render() {
    const { currentUser, showAdminBoard } = this.state;

    return (
      
      <Router>
        <div>
          

          <div>
            <Switch>
              
              
              
              
           <Route exact path ="/" component={Home}/>
              <Route exact path ="/AddNewServive" component={Addnewservice}/>
              <Route exact path= "/Profile" component={Profileo} />
              <Route exact path= "/Rent" component={Rent} />
              <Route exact path= "/ChoosePrb" component={ChoosePrb} />
              <Route exact path= "/Rent/Dio" component={Dio} />
              <Route exact path= "/Home" component={Home} />
              <Route exact path="/Rent/Pulsar" component={Pulser}/>
              <Route exact path="/Rent/HondaCivic" component={HondaCivic}/>
              <Route exact path="/Rent/HondaVezel" component={HondaVezel}/>
              <Route exact path= "/Home" component={Home} /> */}
              <Route exact path= "/MainPage" component={FirstPage} />
              <Route exact path= "/GeoLocation" component={GeoLocation} />
              <Route exact path= "/History" component={History} />
              <Route exact path= "/feedbacks" component={Feedback} />


            {/* <Route exact path={["/","/home"]} component={Home}/> */}
            {/* <Route path={["/Login1"]} component={Login} /> */}
            <Route path={["/Register"]} component={Register} />
            {/* <Route path={["/Login2"]} component={Login} /> */}
            {/* <Route path={["/Admin"]} component={Adminpage}/> */}
            {/* <Route path={["/UserControl"]} component={UserControl}/> */}
            <Route path={["/sos"]} component={Sos}/>
            {/* <Route path={["/Serviceprovidercontrol"]} component={ServicePcontrol}/> */}
            <Route path={["/ContactUs"]} component={ContactUs} />
            <Route path={["/booked"]} component={Timer} />
            </Switch>
            <FooterXXX/>
          </div>
         
        </div>
      </Router>
    );
  }
}

export default App;
