import React from "react";
import ReactDOM from "react-dom";
import { BrowserRouter } from "react-router-dom";

import App from "./App";
import * as serviceWorker from "./serviceWorker";
import FirstPage from "./components/First";
import Register2 from "./components/register";
import Rent from "./components/rent";
import Profileo from "./components/Profileo"
import Sociallink from "./components/sociallink";
import Newservice from "./components/addnewService";
import Create from "./components/Create";
import Demo from "./components/demo";
import Login from "./components/Login";
import Home from './components/Home';
import ChoosePrb from "./components/ChoosePrb";
import Feedback from "./components/Feedback";

ReactDOM.render(
  <BrowserRouter>
      {/* <VerticalTabs/> */}
      {/* {FrontPage/* <ProfileDetails/> */}
      <App/>
  </BrowserRouter>,
  document.getElementById("root")
 
);

serviceWorker.unregister();
