import axios from 'axios';

const USER_API_BASE_URL = 'http://localhost:8080/feedbacks';

class ApiService {

  
    getAllFeedback() {
        return axios.get(USER_API_BASE_URL);
    }
    deleteHistory(id) {
        return axios.delete(USER_API_BASE_URL + '/' + id);
    }
  

    saveFeedBck(Feedback) {
        return axios.post(USER_API_BASE_URL, Feedback);
    }
    editUser(Feedback) {
        return axios.put(USER_API_BASE_URL + '/' + Feedback.id, Feedback);
    }



}

export default new ApiService();